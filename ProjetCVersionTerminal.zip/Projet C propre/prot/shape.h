#ifndef SHAPE_H

    #define SHAPE_H

    //Valeurs correspondantes aux identifiants des formes et des couleurs
    #define circle_ID 0
    #define diamond_ID 1
    #define triangle_ID 2
    #define square_ID 3
    #define blue_ID 0
    #define yellow_ID 1
    #define red_ID 2
    #define green_ID 3 

    typedef struct shape{
        int id_type;
        int id_color;
        struct shape *type_next;
        struct shape *type_prev;
        struct shape *color_next;
        struct shape *color_prev;
        struct shape *next;
    }shape;

    /*Initialise une variable shape avec les valeurs passées en entrée  
    Les différents ID signifient : 
        id = 0 : cercle || bleu
        id = 1 : losange || jaune
        id = 2 : triangle || rouge
        id = 3 : carré || vert */
    shape* create_shape(int type, int color);

    /*Genere 2 entiers de manière aléatoire pour la création d'une forme*/
    shape* create_random_shape(void);
    
    /* Libere tout l'espace mémoire utilise pour stocker shape*/
    void shape_free(shape *s);

    
#endif