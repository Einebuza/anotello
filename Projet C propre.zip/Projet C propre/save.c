#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "prot/shape.h"
#include "prot/list_management.h"
#include "prot/save.h"


void save_game(circular_linked_list *current_game, circular_linked_list *current_next_shapes, int *current_score){

    if (current_game == NULL){
        printf("Couldn't save the game");
        return;
    }

    FILE *save_file;
    save_file = fopen("save.txt","w");

    if (save_file == NULL){
        printf("Save file couldn't be created");
        return;
    }



    fprintf(save_file, "%d ", *current_score);

    shape *p = current_next_shapes->head;

    for (int i = 0; i<current_next_shapes->len; i++){
        fprintf(save_file,"%d %d ", p->id_color, p->id_type);
        p = p-> next;
    }

    p = current_game->head;

    for (int i = 0; i<current_game->len; i++){
        fprintf(save_file,"%d %d ", p->id_color, p->id_type);
        p = p-> next;
    }

    fclose(save_file);

}

void load_game(circular_linked_list *current_game, circular_linked_list *current_next_shapes, doubly_linked_list **dll_color, doubly_linked_list ** dll_type, int *score){

    FILE *save_file;
    save_file = fopen("save.txt","r");

    if (save_file == NULL){
        printf("Save file couldn't be found");
        return;
    }

    int saved_score;
    int add_color;
    int add_type;


    fscanf(save_file, "%d", &saved_score);

    *score = saved_score;

    for (int i = 0; i<5; i++){
        fscanf(save_file,"%d", &add_color);
        fscanf(save_file,"%d", &add_type);
        shape *add_shape = create_shape(add_type, add_color);
        cll_add_shape_right(current_next_shapes, add_shape);
    }

    while (fscanf(save_file,"%d", &add_color) != EOF){
        fscanf(save_file,"%d", &add_type);
        shape *add_shape = create_shape(add_type, add_color);
        cll_add_shape_right(current_game, add_shape);
        dll_add_shape_right(dll_color[add_color], dll_type[add_type], add_shape);
    }

    fclose(save_file);
}