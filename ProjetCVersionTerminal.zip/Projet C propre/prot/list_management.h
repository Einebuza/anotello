#ifndef LIST_MANAGEMENT_H

    #define LIST_MANAGEMENT_H
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include "shape.h"


    /*Definition de la structure*/
    typedef struct{
        shape* head;
        shape* tail;
        int len;
    }circular_linked_list;

    typedef struct{
        shape* head;
        shape* tail;
        int len;
    }doubly_linked_list;


    /*Fonction d'initialisation*/
    /*Initialise une liste chainee circulaire vide*/
    circular_linked_list *create_circular_linked_list(void);

    /*Initialise une liste chainee doublement chainee vide*/
    doubly_linked_list *create_doubly_linked_list();


    /*Fonction d'ajout d'element*/
        /*Ajoute une shape a la liste à gauche dans le jeu. 
        Du point de vu de la liste doublement chainee, la shape ajoutée devient la tête de liste.
        dll = doubly linked list*/
        void dll_add_shape_left(doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s);

        /*Ajoute une shape a la liste à droite. 
        Du point de vu de la liste doublement chainee, la shape ajoutée devient la queue de liste.
        dll = doubly linked list*/
        void dll_add_shape_right_by_color(doubly_linked_list *dll_color, shape *s);
        void dll_add_shape_right_by_type(doubly_linked_list *dll_type, shape *s);
        void dll_add_shape_right(doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s);

        /*Ajoute une shape a la liste à gauche dans le jeu. 
        Du point de vu de la liste circulaire, la shape ajoutee devient la tete de liste.
        cll = circular linked list*/
        void cll_add_shape_left(circular_linked_list *cll, shape *s);

        /*Ajoute une shape a la liste a droite. 
        Du point de vu de la liste circulaire, la shape ajoutee devient la queue de liste.
        cll = circular linked list*/
        void cll_add_shape_right(circular_linked_list *cll, shape *s);


    /*Fonction d'affichage*/
        /*Affiche le type et la couleur d'une shape passee en parametre*/
        void show_shape(shape *s);

        /*Affiche les elements d'une liste doublement chainee de couleur*/
        void show_dll_color(doubly_linked_list *dll);

        /*Affiche les elements d'une liste doublement chainee de type*/
        void show_dll_type(doubly_linked_list *dll);

        /*Affiche les element d'une liste chainee circulaire*/
        void show_cll(circular_linked_list *cll);


    /*Fonction de suppression d'element*/
        /*Supprime la shape de la liste passée en parametre*/
        void cll_delete_shape(circular_linked_list *cll, shape *s);

        /*Supprime la liste chainee circulaire*/
        void cll_free(circular_linked_list *cll);

        /*Supprime la shape de la liste passée en paramètre*/
        void dll_delete_shape(doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s);


    /*Fonction de liberation de l'espace memoire*/
        /*Libere l'espace memoire de la liste doublement chainee*/
        void dll_free(doubly_linked_list *dll);
        
        /*Libere l'espace memoire de la liste chainee circulaire*/
        void cll_free(circular_linked_list *cll);

        /*Supprime et libere l'espace d'une shape*/
        void delete_shape(circular_linked_list *cll, doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s);

    /*Opérations de décalage*/
        /*Mise à jour des liens dans la liste doublement chaînée de type après un décalage*/
        void update_link_type(circular_linked_list *cll, doubly_linked_list *dll_color, int to_update_id_type);
        /*Mise à jour des liens dans la liste doublement chaînée de couleur après un décalage*/
        void update_link_color(circular_linked_list *cll, doubly_linked_list *dll_color, int to_update_id_color);

        /*Opération de décalage par rapport au type*/
        void shift_type(circular_linked_list *cll, doubly_linked_list *dll_type, doubly_linked_list **color);
        /*Opération de décalage par rapport à la couleur*/
        void shift_color(circular_linked_list *cll, doubly_linked_list *dll_color, doubly_linked_list **type);

    /*Fonctions de test*/
        //Fonction qui supprime les éléments consécutifs de même type
        void consecutive_type(circular_linked_list *cll, doubly_linked_list *dll_type, doubly_linked_list **color, shape* current_delete, int count_type, int *score, int multiplier);
        //Fonction qui supprime les éléments consécutifs de même couleur
        void consecutive_color(circular_linked_list *cll, doubly_linked_list *dll_color, doubly_linked_list **type, shape* current_delete, int count_color, int *score, int multiplier);

        // Fonction de test qui va permettre de détecter les suites de 3 ou plus éléments du même type ou de la même couleur : renvoie 1 si il y a suppression, -1 si la liste est pleine, 0 sinon
        int checklist(circular_linked_list *cll, doubly_linked_list **color, doubly_linked_list **type, int* score, int multiplier);

    //Autres opérations :
        //Permet de supprimer et rajouter une forme en FIFO (first in first out) 
        void refresh_next_shapes(circular_linked_list *cll);

        //Permet de réinitialiser la liste des 5 pièces suivantes
        void reset_next_shapes(circular_linked_list *cll);

       
#endif