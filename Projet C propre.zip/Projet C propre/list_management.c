#include "prot/shape.h"
#include "prot/list_management.h"

/*Initialiser liste*/
circular_linked_list* create_circular_linked_list(void){
    circular_linked_list *cll = malloc(sizeof(circular_linked_list));
    if (cll == NULL){
        return NULL;
    }
    cll->head = NULL;
    cll->tail = NULL;
    cll->len = 0;
    return cll;
}

doubly_linked_list *create_doubly_linked_list(void){
    doubly_linked_list *dll = malloc(sizeof(doubly_linked_list));
    if (dll == NULL){
        return NULL;
    }
    dll->head = NULL;
    dll->tail = NULL;
    dll->len = 0;
    return dll;
}

/*show*/
void show_shape(shape *s)
{
    if (s == NULL)
        return;
    printf("%d %d\n", s->id_type, s->id_color);
}

void show_dll_color(doubly_linked_list *dll)
{
    printf("_______________DLL COLOR______________\n");
    shape *current = dll->head;
    printf("Tête : ");
    show_shape(dll->head);
    printf("Liste : ");
    for (int i = 0; i < dll->len; i++)
    {
        show_shape(current);
        current = current->color_next;
    }
    printf("Queue : ");
    show_shape(dll->tail);
    printf("_______________________________\n");
}

void show_dll_type(doubly_linked_list *dll)
{
    printf("_______________DLL TYPE______________\n");
    shape *current = dll->head;
    printf("Tête : ");
    show_shape(dll->head);
    printf("Liste : ");
    for (int i = 0; i < dll->len; i++)
    {
        show_shape(current);
        current = current->type_next;
    }
    printf("Queue : ");
    show_shape(dll->tail);
    printf("_______________________________\n");
}

void show_cll(circular_linked_list *cll)
{
    printf("________________CLL_____________\n");
    shape *current = cll->head;
    printf("Tête : ");
    show_shape(cll->head);
    printf("Liste : ");
    for (int i = 0; i < cll->len; i++)
    {
        show_shape(current);
        current = current->next;
    }
    printf("Queue : ");
    show_shape(cll->tail);
    printf("_______________________________\n");
}


/*Ajouter element a la liste*/

void cll_add_shape_left(circular_linked_list *cll, shape *s){
    /*Cas ou la liste est vide*/
    if (cll->len == 0){
        cll->head = s;
        cll->tail = s;
        s->next = s;
    }
    /*Cas où la liste possede au moins un element*/
    else{
        cll->tail->next = s;
        s->next = cll->head;
        cll->head = s;
    }
    cll->len++;
}

void cll_add_shape_right(circular_linked_list *cll, shape *s){
    /*Cas ou la liste est vide*/
    if (cll->len == 0){
        cll->head = s;
        cll->tail = s;
        s->next = s;
    }
    /*Cas où la liste possede au moins un element*/
    else{
        cll->tail->next = s;
        s->next = cll->head;
        cll->tail = s;
    }
    cll->len++;
}

void dll_add_shape_left(doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s){
    /*Ajout par rapport à la couleur*/
    if (dll_color->len == 0){
        dll_color->head = s;
        dll_color->tail = s;
    }
    else{
        s->color_next = dll_color->head;
        s->color_prev = dll_color->tail;
    }

    dll_color->tail->color_next = s;
    dll_color->head->color_prev = s;
    dll_color->head = s;
    dll_color->len++;

    /*Ajout par rapport à la forme*/
    if (dll_type->len == 0){
        dll_type->head = s;
        dll_type->tail = s;
    }
    else{
        s->type_next = dll_type->head;
        s->type_prev = dll_type->tail;
    }
    dll_type->tail->type_next = s;
    dll_type->head->type_prev = s;
    dll_type->head = s;
    dll_type->len++;
}

void dll_add_shape_right_by_color(doubly_linked_list *dll_color, shape *s){
    /*Ajout par rapport à la couleur*/
    if (dll_color->len == 0){
        dll_color->head = s;
        dll_color->tail = s;
    }
    else{
        s->color_next = dll_color->head;
        s->color_prev = dll_color->tail;
    }
    dll_color->tail->color_next = s;
    dll_color->head->color_prev = s;
    dll_color->tail = s;
    dll_color->len++;
}

void dll_add_shape_right_by_type(doubly_linked_list *dll_type, shape *s){
    /*Ajout par rapport à la forme*/
    if (dll_type->len == 0){
        dll_type->head = s;
        dll_type->tail = s;
    }
    else{
        s->type_next = dll_type->head;
        s->type_prev = dll_type->tail;
    }
    dll_type->tail->type_next = s;
    dll_type->head->type_prev = s;
    dll_type->tail = s;
    dll_type->len++;
}

void dll_add_shape_right(doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s){
    dll_add_shape_right_by_color(dll_color, s);
    dll_add_shape_right_by_type(dll_type, s);
}
/*Suppression*/

void cll_delete_shape(circular_linked_list *cll, shape *s){
    /*La fonction s'occupe juste de casser les liens et non de liberer les shapes*/
    /*Cas ou il n'y a qu'un seul element*/
    if (cll->len == 0) {
        return; // liste vide ou pointeur invalide
    }
    if (cll->len == 1){
        cll->head = NULL;
        cll->tail = NULL;
    }
    else{
        /*Cas où l'element a supprimer est la tete*/
        if (cll->head == s){
            cll->head = cll->head->next;
            cll->tail->next = cll->head;
        }
        /*operation realise peu importe le cas dans lequel nous nous trouvons*/
        else{
            shape *p = cll->head;
            while (p->next != s){
                p = p->next;
            }
            p->next = s->next;
            /*Cas ou l'element a supprimer est la queue*/
            if (cll->tail == s){
                cll->tail = p;
            }
        } 
    }
    cll->len--;
}


void dll_delete_shape(doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s){
/*La fonction s'occupe juste de casser les liens et non de liberer les shapes*/
    if (s == NULL || dll_color->len == 0 || dll_type->len == 0) {
        printf("dll_delete_shape error : empty list");
        return;
    }

    if (dll_color->len == 1){
        dll_color->head = NULL;
        dll_color->tail = NULL;
    }
    else{
        if (dll_color->tail == s){
            dll_color->tail = dll_color->tail->color_prev;
        }
        if (dll_color->head == s){
            dll_color->head = dll_color->head->color_next;
        }
        s->color_prev->color_next = s->color_next;
        s->color_next->color_prev = s->color_prev;
    }
    
    if (dll_type->len == 1){
        dll_type->head = NULL;
        dll_type->tail = NULL;
    }
    else{
        if (dll_type->tail == s){
            dll_type->tail = dll_type->tail->type_prev;
        }
        if (dll_type->head == s){
            dll_type->head = dll_type->head->type_next;
        }
        s->type_prev->type_next = s->type_next;
        s->type_next->type_prev = s->type_prev;
    }

    dll_color->len--;
    dll_type->len--;
}

void delete_shape(circular_linked_list *cll, doubly_linked_list *dll_color, doubly_linked_list *dll_type, shape *s){

   

    dll_delete_shape(dll_color, dll_type, s);
    cll_delete_shape(cll, s);

    free(s);

    
}


void dll_free(doubly_linked_list *dll){
    /*La suppression des maillions est faite dans une autre fonction*/
    free(dll);
}

void cll_free(circular_linked_list *cll){
    /*La suppression des maillions est faite dans une autre fonction*/
    free(cll);
}


/*Operation de decalage*/
void update_link_color(circular_linked_list *cll, doubly_linked_list *dll_color, int to_update_id_color){
    shape *current_cll = cll->head;
    int count = 0;
    int len_color = dll_color->len;

    if (dll_color->len == 1){
        return;
    }

    //Reset liste doublement chainee
    dll_color->len = 0;
    dll_color->head = NULL;
    dll_color->tail = NULL;

    while (count<len_color){
        if (current_cll->id_color == to_update_id_color){
            dll_add_shape_right_by_color(dll_color, current_cll);
            count++;
        }
        current_cll = current_cll->next;
    }
}


void shift_type(circular_linked_list *cll, doubly_linked_list *dll_type, doubly_linked_list **color)
{
    int tmp;
    shape *current = dll_type->head;
    int updated_color[] = {0,0,0,0};

    for (int i = 0; i < dll_type->len-1; i++)
    {
        tmp = current->id_color;
        updated_color[current->id_color] = 1;
        updated_color[current->type_next->id_color] = 1;
        current->id_color = current->type_next->id_color;
        current->type_next->id_color = tmp;
        current = current->type_next;
    }
    for (int j = 0; j<4; j++){
        if (updated_color[j]){
            update_link_color(cll, color[j], j);
        }
    }
}

void update_link_type(circular_linked_list *cll, doubly_linked_list *dll_type, int to_update_id_type){
    shape *current_cll = cll->head;
    int count = 0;
    int len_type = dll_type->len;

    if (dll_type->len == 1){
        return;
    }

    //Reset liste doublement chainee
    dll_type->len = 0;
    dll_type->head = NULL;
    dll_type->tail = NULL;


    while (count<len_type){
        if (current_cll->id_type == to_update_id_type){
            dll_add_shape_right_by_type(dll_type, current_cll);
            count++;
        }
        current_cll = current_cll->next;
    }
}


void shift_color(circular_linked_list *cll, doubly_linked_list *dll_color, doubly_linked_list **type)
{
    int tmp;
    shape *current = dll_color->head;
    int updated_type[] = {0,0,0,0};

    for (int i = 0; i < dll_color->len-1; i++)
    {   
        updated_type[current->id_type] = 1;
        updated_type[current->color_next->id_type] = 1;
        tmp = current->id_type;
        current->id_type = current->color_next->id_type;
        current->color_next->id_type = tmp;
        current = current->color_next;
    }
    for (int j = 0; j<4; j++){
        if (updated_type[j]){
            update_link_type(cll, type[j], j);
        }
    }
}



void consecutive_type(circular_linked_list *cll, doubly_linked_list *dll_type, doubly_linked_list **color, shape* current_delete, int count_type, int *score, int multiplier){
    for (int j = 0; j < count_type; j++){ 
        shape *tmp = current_delete->next;
        delete_shape(cll, color[current_delete->id_color], dll_type, current_delete);
        *score = *score + (100 * multiplier);
        current_delete = tmp;
    }
}


void consecutive_color(circular_linked_list *cll, doubly_linked_list *dll_color, doubly_linked_list **type, shape* current_delete, int count_color, int *score, int multiplier){
    for (int j = 0; j < count_color; j++){
        shape *tmp = current_delete->next;
        delete_shape(cll, dll_color, type[current_delete->id_type], current_delete);
        *score = *score + (100 * multiplier);
        current_delete = tmp;
    }
}

int checklist(circular_linked_list *cll, doubly_linked_list **color, doubly_linked_list **type, int* score, int multiplier){

    // Si la liste est vide, on n'a rien à vérifier ni à supprimer : 
    if (cll->head == NULL){
        return 0;
    }

    // Pointeur pour le parcours de liste
    shape *current_game = cll->head;
    shape *current_type = cll->head; // Garde un pointeur sur la premiere shape a supprimer lors de la detection par type
    shape *current_color = cll->head; // Garde un pointeur sur la premiere shape a supprimer lors de la detection par couleur
    

    // Initialisation variable
    int id_color2delete = cll->head->id_color;
    int id_type2delete = cll->head->id_type;
    int count_color = 1;
    int count_type = 1;
    int i = 0, test_oldest = 0;

    // Parcours de liste
    while (i < cll->len - 1){ 
        current_game = current_game->next;

        // Test par rapport au type
        if (current_game->id_type != id_type2delete){
            if (count_type >= 3){
                consecutive_type(cll, type[id_type2delete], color, current_type, count_type, score, multiplier);
                return 1;
            }
            else{
                id_type2delete = current_game->id_type;
                current_type = current_game;
                count_type = 1;
                test_oldest = 1;
            }
        }
        else{
            count_type++;
        }
        // Test par rapport à la couleur
        if (current_game->id_color != id_color2delete){ 
            if (count_color >= 3){
                consecutive_color(cll, color[id_color2delete], type, current_color, count_color, score, multiplier);
                return 1;
            }
            else{
                id_color2delete = current_game->id_color;
                current_color = current_game;
                count_color = 1;
                test_oldest = 0;
            }
        }
        else{
            count_color++;
        }
        i++;
    }
    

    //On sort de la boucle mais il peut y avoir des formes ou couleurs consécutives non supprimées liées à notre condition de suppression
    //test_oldest permet de savoir si la premiere suppression a effectuer est sur la forme ou sur la couleur
    if (test_oldest == 0){
        if (count_type >= 3){
            consecutive_type(cll, type[id_type2delete], color, current_type, count_type, score, multiplier);
            return 1;
        }
        if (count_color >= 3){
            consecutive_color(cll, color[id_color2delete], type, current_color, count_color, score, multiplier);
            return 1;
        }
    }

    else{
        if (count_color >= 3){
                consecutive_color(cll, color[id_color2delete], type, current_color, count_color, score, multiplier);
                return 1;
        }
        if (count_type >= 3){
                consecutive_type(cll, type[id_type2delete], color, current_type, count_type, score, multiplier);
                return 1;
        }

    }

    // S'il y a plus de 15 elements :  on fait le test à la fin de la fonction car il se peut qu'après modification la liste ne soit plus remplie
    if (cll->len > 15){
        return -1;
    }

    return 0; // Il n'y a pas eu de suppression
}



// Autres opérations
void refresh_next_shapes(circular_linked_list *cll){
    shape *new_shape = create_random_shape();
    cll_add_shape_right(cll, new_shape);
    cll_delete_shape(cll, cll->head);
}


void reset_next_shapes(circular_linked_list *cll){
    for (int i = 0; i<5; i++){
        refresh_next_shapes(cll);
    }
}

