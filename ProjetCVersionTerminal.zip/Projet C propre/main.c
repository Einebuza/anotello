#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "prot/shape.h"
#include "prot/list_management.h"
#include "prot/rank.h"
#include "prot/save.h"



/*Fonction permettant l'affichage dans terminal*/
void display_cll(circular_linked_list* cll){
    /*Permet l'affichage d'une liste chainee circulaire dans le terminal*/
    shape* current = cll->head;
    int id_type, id_color, id_shape;
    for (int i=0; i<cll->len; i++){
        id_type = current->id_type;
        id_color = current->id_color;
        id_shape = id_type*10 + id_color;
        current = current->next;
        switch (id_shape){
        case 0:
            printf("\033[39m\033[34mO\033[39m ");//blue_circle
            break;
        case 1:
            printf("\033[39m\033[33mO\033[39m ");//yellow_circle
            break;
        case 2:
            printf("\033[39m\033[31mO\033[39m ");//red_circle
            break;
        case 3:
            printf("\033[39m\033[32mO\033[39m "); //green_circle
            break;
        case 10:
            printf("\033[39m\033[34mL\033[39m ");//blue_diamond
            break;
        case 11:
            printf("\033[39m\033[33mL\033[39m ");
            break;
        case 12:
            printf("\033[39m\033[31mL\033[39m ");
            break;
        case 13:
            printf("\033[39m\033[32mL\033[39m ");
            break;
        case 20:
            printf("\033[39m\033[34mT\033[39m ");//blue_triangle
            break;
        case 21:
            printf("\033[39m\033[33mT\033[39m ");
            break;
        case 22:
            printf("\033[39m\033[31mT\033[39m ");
            break;
        case 23:
            printf("\033[39m\033[32mT\033[39m ");
            break;
        case 30:
            printf("\033[39m\033[34mC\033[39m ");//blue_square
            break;
        case 31:
            printf("\033[39m\033[33mC\033[39m ");
            break;
        case 32:
            printf("\033[39m\033[31mC\033[39m ");
            break; 
        case 33:
            printf("\033[39m\033[32mC\033[39m ");
            break;
        default:
            printf("Error");
            break;
    }
    }
    printf("\n");
}

void display_frame(void) {
    /*Permet de dessiner une ligne de pointiller*/
    for (int i = 0; i < 80; i++) {
        printf("-");
    }
    printf("\n");
}

void center_text(char *text) {
    /*Affiche un texte centré*/
    int length = strlen(text);
    int padding = (80 - length) / 2;
    printf("|%*s%s%*s|\n", padding - 1, " ", text, padding, " ");
}

void clear_buffer(void)
    /*Vide le buffer pour eviter les problemes lors des inputs utilisateurs*/
{
    int c = 0;
    while (c != '\n' && c != EOF)
    {
        c = getchar();
    }
}

void clear_terminal(void) {
    /*Efface tout le contenue du terminal*/
    printf("\033[2J");
    printf("\033[0;0H");
}

void display_hud(circular_linked_list *game, circular_linked_list *next5shapes, char *text, int *score){
    /*Affichage d'une interface de jeu dans le terminal*/
    clear_terminal();
    display_frame();
    center_text(text);
    display_frame();
    printf("Score : %d\n", *score);
    printf("Next shapes : ");
    display_cll(next5shapes);
    printf("\n\n");
    display_cll(game);
    printf("\n\n");
    display_frame();
}

int display_input_action(circular_linked_list *game, circular_linked_list *next5shapes, char *text, int *score){
    /*Affichage des differentes actions possibles et recuperation de l'input utilisateur*/
    int input = -10;
    while (input != 1 && input != 2 && input != 3 && input != 9 && input != 0){
        display_hud(game, next5shapes, text, score);

        printf(" 1 : Placement a gauche\n");
        printf(" 2 : Placement a droite\n");
        printf(" 3 : Decalage a gauche (forme ou couleur)\n");
        printf(" 9 : Sauvegarde\n");
        printf(" 0 : Quitter\n");
        if (input == -10){
            printf("Quelle action souhaitez-vous faire ? : ");
            scanf("%d", &input);
            clear_buffer();
        }
        else{
            printf("Erreur ! Choix invalide ! Recommencez : ");
            scanf("%d", &input);
            clear_buffer();
        }

    }
    return input;
}

int display_input_shift(circular_linked_list *game, circular_linked_list *next5shapes, char *text, int *score){
    /*Affichage des differentes decalages possibles et recuperation de l'input utilisateur*/
    int input1=-10, input2=-10;
    while (input1 != 1 && input1 != 2){
        display_hud(game, next5shapes, text, score);
        printf(" 1 : Decalage par piece\n");
        printf(" 2 : Decalage par couleur\n");
        if(input1 == -10){
            printf("Choix : ");
            scanf("%d", &input1);
            clear_buffer();
        }
        else{
            printf("Erreur ! Choix non valide, recommencez : ");
            scanf("%d", &input1);
            clear_buffer();

        }
        
    }
    if (input1 == 1){ //Decalage par piece
        while (input2 != 1 && input2 != 2 && input2 != 3 && input2 != 4){
        display_hud(game, next5shapes, text, score);
        printf(" 1 : Decalage par cercle\n");
        printf(" 2 : Decalage par losange\n");
        printf(" 3 : Decalage par triangle\n");
        printf(" 4 : Decalage par carre\n");
            if(input2 == -10){
                printf("Choix : ");
                scanf("%d", &input2);
                clear_buffer();
            }
            else{
                printf("Erreur ! Choix non valide, recommencez : ");
                scanf("%d", &input2);
                clear_buffer();
            }
        }
    }
    else{ //Decalage par forme
        while (input2 != 1 && input2 != 2 && input2 != 3 && input2 != 4){
        display_hud(game, next5shapes, text, score);
        printf(" 1 : Decalage par bleu\n");
        printf(" 2 : Decalage par jaune\n");
        printf(" 3 : Decalage par rouge\n");
        printf(" 4 : Decalage par vert\n");
            if(input2 == -10){
                printf("Choix : ");
                scanf("%d", &input2);
                clear_buffer();
            }
            else{
                printf("Erreur ! Choix non valide, recommencez : ");
                scanf("%d", &input2);
                clear_buffer();
            }
        }
    }
    return (input1)*10 + (input2);
}

void display_main_menu(void){
    /*Affichage du menu principal*/
    char text1[] = "TETRISTE - CPROJEKT";
    char text2[] = "by S.SO & F.ZHANG";
    char text3[] = "\033[39m\033[32mC \033[39m\033[33mT \033[39m\033[34mS \033[39m\033[35mD\033[39m ";

    clear_terminal();
    display_frame();
    center_text(text1);
    center_text(text2);
    printf("|%*s%s%*s|\n", 35, " ", text3, 35, " ");
    display_frame();
    printf("\n\n");
}

int input_main_menu(void){
    /*Affichage des actions possibles dans le menu principal et recuperation de l'input utilisateur*/
    int value = -10;
    while (value !=1 && value != 2 && value != 3 && value != 0){
        display_main_menu();
        printf("1 : Start Game\n");
        printf("2 : Load Game\n");
        printf("3 : Leaderboard\n");
        printf("0 : Quitter\n");
        if (value == -10){
             printf("Choix : ");
             scanf("%d", &value);
             clear_buffer();
            }
        else{
            printf("Erreur ! Choix non valide, recommencez : ");
            scanf("%d", &value);
            clear_buffer();
            }
        }
    return value;
}

void display_leaderboard(const char *leaderboard) {
    /*Affichage du classement*/
    clear_terminal();
    FILE *file = fopen(leaderboard, "r");

    display_frame();
    char text1[] = "LEADERBOARD - TOP 10";
    center_text(text1);
    display_frame();

    if (file == NULL) {
        printf("Error");
        return;
    }

    int score;
    int i=1;
    char nickname[17];  // Adjust the buffer size as needed

    while (fscanf(file, "%d %17s", &score, nickname) == 2) {
        printf("%d. %s - %d\n", i, nickname, score);
        i++;
    }

    fclose(file);
}

/*Fonction de jeu*/
/*Lorsque le jeu est termine, on libere la memoire*/
void exit_game(circular_linked_list *game, circular_linked_list *next5shapes, doubly_linked_list **color, doubly_linked_list **type, int *game_state){
    
    shape *current = game->head;
    shape *tmp;
    int len_cll = game->len;

    for (int i=0; i<len_cll; i++){
        tmp = current;
        current = current->next;
        delete_shape(game, color[tmp->id_color], type[tmp->id_type],tmp);
    }

    current = next5shapes->head;
    len_cll = next5shapes->len;

    for (int i=0; i<len_cll; i++){
        tmp = current;
        current = current->next;
        cll_delete_shape(next5shapes, tmp);
    }


    for (int j=0; j<4; j++){
        free(type[j]);
        free(color[j]);
    }

    free(game);
    free(next5shapes);
    *game_state = 0;
}

void selector_main_menu(circular_linked_list *game, circular_linked_list *next5shape, doubly_linked_list **color, doubly_linked_list **type, char *leaderboard, int *game_state, int* score, int input) {
    switch (input) {
        case 1:
            // Initialisation de la première liste des 5 formes 
            for (int i = 0 ; i<5 ; i++){
            shape *rand_shape = create_random_shape();
            cll_add_shape_right(next5shape,rand_shape);
            }
            *game_state = 1;
            break;

        case 2:
            *game_state = 1;
            load_game(game, next5shape, color, type, score);
            break;

        case 0:
            *game_state = 0;
            display_leaderboard(leaderboard);
            break;

        default:
            printf("Invalid imput");
            break;
    }
}

void selector_shift(circular_linked_list *game, doubly_linked_list **color, doubly_linked_list **type, int input){
    printf("%d", input);
    switch (input)
    {
    case 11:
        shift_type(game, type[0], color);

        break;
    case 12:
        shift_type(game, type[1], color);

        break;
    case 13:
        shift_type(game, type[2], color);

        break;
    case 14:
        shift_type(game, type[3], color);

        break;
    case 21:
        shift_color(game, color[0], type);

        break;
    case 22:
        shift_color(game, color[1], type);

        break;
    case 23:
        shift_color(game, color[2], type);

        break;
    case 24:
        shift_color(game, color[3], type);

        break;
    
    default:
    printf("Invalid input");
        break;
    }
}

void selector_action(circular_linked_list *game, circular_linked_list *next5shape, doubly_linked_list **color, doubly_linked_list **type, char *leaderboard, char *title, int *game_state, int* score, int *multiplier, int input){
    int add_color = next5shape->head->id_color;
    int add_type = next5shape->head->id_type;
    shape *add_shape = create_shape(add_type, add_color);
    
    switch (input){
        case 1:
            cll_add_shape_left(game, add_shape);
            dll_add_shape_left(color[add_color], type[add_type], add_shape);
            refresh_next_shapes(next5shape);
            *multiplier = 1;
            break;
        case 2:
            
            cll_add_shape_right(game, add_shape);
            dll_add_shape_right(color[add_color], type[add_type], add_shape);
            refresh_next_shapes(next5shape);
            *multiplier = 1;
            break;
        case 3:
            int switch_value = display_input_shift(game, next5shape, title, score);
            selector_shift(game, color, type, switch_value);
            *multiplier = 2;
            free(add_shape);
            break;
        case 9:
            save_game(game, next5shape, score);
            exit_game(game, next5shape, color, type, game_state);
            free(add_shape);
            break;        
        case 0:
            exit_game(game, next5shape, color, type, game_state);
            free(add_shape);
            break;
        default:
            printf("Invalid input");
            free(add_shape);
            break;
    }
}

char *display_input_game_over(int *score) {
    char text1[] = "Game Over :C";
    char text2[] = "Your score was : \n";
    char str_score[30];
    char *nickname = (char *)malloc(17 * sizeof(char));

    if (nickname == NULL) {
        printf("ERROR MEMORY MALLOC");
        return NULL;
    }

    clear_terminal();
    display_frame();
    center_text(text1);
    display_frame();
    printf("\n\n");
    center_text(text2);
    sprintf(str_score, "%d", *score);
    center_text(str_score);
    printf("\n\n");

    // Initialiser nickname[0] avec un espace
    nickname[0] = ' ';

    printf("Enter your nickname (16 characters max): ");
    scanf("%16s", nickname + 1);  // Commencer à partir de la deuxième position

    return nickname;
}

int main(){

    //Initialisation des pointeurs
    circular_linked_list *game = create_circular_linked_list();;     //liste principale qui comprends toutes les formes en jeu

    doubly_linked_list* triangle = create_doubly_linked_list();
    doubly_linked_list* square = create_doubly_linked_list();
    doubly_linked_list* circle = create_doubly_linked_list();
    doubly_linked_list* diamond = create_doubly_linked_list();

    doubly_linked_list *type[4] = {circle, diamond, triangle, square};

    doubly_linked_list* red = create_doubly_linked_list();
    doubly_linked_list* blue = create_doubly_linked_list();
    doubly_linked_list* yellow = create_doubly_linked_list();
    doubly_linked_list* green = create_doubly_linked_list();

    doubly_linked_list *color[4] = {blue, yellow, red, green};

    circular_linked_list *next5shape = create_circular_linked_list();
    srand(time(NULL));  // Initialisation du générateur de nombre aléatoire

   //Variable du jeu
    int score_value = 0;
    int game_state_value = 1;
    int action_value;
    int *game_state = &game_state_value;
    int *score = &score_value;
    int multiplier_value = 1;
    int *multiplier = &multiplier_value;

    char title[] = "TETRISTE - CPROJEKT";
    char leaderboard[] = "best_scores.txt"; 

    action_value = input_main_menu();
    selector_main_menu(game, next5shape, color, type, leaderboard, game_state, score, action_value);

    while(*game_state != 0){

        action_value = display_input_action(game, next5shape, title, score);
        *multiplier = 1;
        selector_action(game, next5shape, color, type, leaderboard, title, game_state, score, action_value);


        //Detecte les cascades = plus grand multiplicateur de score
        while (checklist(game, color, type, score, *multiplier) == 1){
            *multiplier *= 2;  // Les suppressions en cascade donnent plus de points ! 
            checklist(game, color, type, score, *multiplier);
        }
        // On test si la partie est perdue :
        if (checklist(game, color, type, score, *multiplier) == -1){
            char *nickname = display_input_game_over(score);
            update_leaderboard(leaderboard, nickname, score);
            exit_game(game, next5shape, color, type, game_state);
            free(nickname);
            }
    }
    
    display_leaderboard(leaderboard);
    return 0;
}
