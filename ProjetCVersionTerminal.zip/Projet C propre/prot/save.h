#ifndef SAVE_H
    #define SAVE_H
    #include "list_management.h"


    //Fonction de sauvegarde : stockage sous forme d'une suite d'entiers dans un fichier .txt
    void save_game(circular_linked_list *current_game, circular_linked_list *current_next_shapes, int *current_score);

    //Fonction de chargement : traduction d'un fichier .txt pour renvoyer la liste principale du jeu
    void load_game(circular_linked_list *current_game, circular_linked_list *current_next_shapes, doubly_linked_list **dll_color, doubly_linked_list ** dll_type, int *score);

#endif