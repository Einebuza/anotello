#ifndef RANK_H
    #define RANK_H
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>

typedef struct rank{
    int rank_score;
    char *rank_name;
}rank;

// Cette fonction initialise un rang du classement
rank *rank_init(void);

// Cette fonction met à jour un classement et l'affiche
void update_leaderboard(char *leaderboard, char * new_name, int *score);




#endif