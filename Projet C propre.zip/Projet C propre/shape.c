#include "prot/shape.h"
#include "prot/list_management.h"
#include <time.h>


shape* create_shape(int type, int color){
    shape *s = malloc(sizeof(shape));
    if (s == NULL){
        return NULL;
    }
    s->id_type = type;
    s->id_color = color;
    s->type_next = NULL;
    s->type_prev = NULL;
    s->color_next = NULL;
    s->color_prev = NULL;
    s->next = NULL;
    return s;
}

shape* create_random_shape(void){  // Initialization, should only be called once.
    int color = rand()%4;      // Returns a pseudo-random integer between 0 and 4
    int type = rand()%4;
    return create_shape(type, color);
}

void shape_free(shape *s){
    free(s);
}